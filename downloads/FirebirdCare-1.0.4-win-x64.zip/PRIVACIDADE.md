# Credenciais e privacidade - Firebird Care 1.0.4

Desenvolvido por Luan Paranhos.

## Uso das credenciais

- Digite SYSDBA e a senha do Firebird na secao Credenciais.
- Analise, backup, restauracao e recuperacao ficam inativos ate o preenchimento.
- Um clique na area de um comando bloqueado ou na navegacao dessas operacoes
  abre um lembrete e retorna aos campos de credenciais.
- O preenchimento e exigido novamente apos cada procedimento. Senhas vazias,
  somente com espacos ou com quebras de linha nao liberam os comandos.
- Verificar o runtime, consultar o historico e configurar o tema nao exigem senha.

## Sem persistencia da senha

A senha nao e salva pelo aplicativo em configuracoes, historico, arquivos
temporarios, linha de comando ou variaveis de ambiente. E enviada aos
utilitarios oficiais por uma entrada padrao redirecionada, usando
-fetch_password stdin. Nao ha opcao de lembrar senha nem senha padrao.

Mensagens capturadas que reproduzam a senha sao ocultadas antes de guardar
o registro no aplicativo. Isso abrange stdout, stderr, entradas acompanhadas
do firebird.log, detalhes do resultado e mensagens de excecao. O log ja
saneado e usado na tela, pesquisa, copia, exportacao e persistencia.
Nao e preciso gravar a senha para apaga-la do log depois.

O campo de senha e limpo apos sucesso, falha, resultado inconclusivo ou
cancelamento, e ao fechar. Os buffers mutaveis de senha controlados pelo
aplicativo sao zerados. A senha precisa estar em memoria durante o uso;
nao se promete apagar fisicamente todas as copias internas do WPF, .NET,
utilitarios, memoria do sistema, dumps ou arquivos de paginacao.

O programa nao modifica logs preexistentes produzidos por outros programas
nem configura instalacoes globais do Firebird. Os utilitarios oficiais
nao recebem a senha por argumentos, scripts ou arquivos de senha.

## Limite importante do modo embedded

O pacote usa apenas Providers = Engine13, sem instalar um servidor.
O Firebird embedded nao autentica senhas. Exigir SYSDBA e senha significa
exigir preenchimento, nao confirmar que a senha corresponde a um usuario
em um servidor. Uma senha diferente tambem pode permitir o procedimento.

Portanto, este bloqueio nao impede acesso ao FDB por quem possui permissoes
de arquivo no Windows. Para autenticar a senha de verdade e necessario
conectar a um servidor Firebird configurado, o que altera o modo de uso
deste pacote. Proteja os arquivos de banco com as permissoes do Windows.

Documentacao oficial:
https://www.firebirdsql.org/file/documentation/chunk/en/refdocs/fblangref40/fblangref40-security.html

## Role

Role e um conjunto nomeado de permissoes SQL no Firebird, nao uma senha.
O campo foi retirado da interface para simplificar o fluxo com SYSDBA.
