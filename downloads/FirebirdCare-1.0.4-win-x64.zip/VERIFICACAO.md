# Verificação da versão 1.0.4

Data: 2026-10-09

## Ambiente

- Windows x64, SDK .NET 8.0.425 portátil.
- Runtime oficial Firebird 4.0.7.3271 x64 incluído no pacote.
- `Providers = Engine13` no runtime usado pelos testes.
- Arquivos de teste criados em `work/regression-1.0.4-final-20261009-191732`, sem acesso a bancos do usuário.

## Compilação e testes

Compilação Release x64 do aplicativo e do executor de regressão: zero avisos e zero erros.

Resultado do executor:

```text
PASS concurrent logging: 20,000 lines retained, bounded preview
PASS dispatcher and navigation during synchronous work: 10 heartbeats
PASS log flood: 60,000 lines saved, 37 UI heartbeats, complete-log search
PASS cancellation: UI remains responsive while cancellation callbacks run
PASS completion notifications: result states, saved history, errors, cancellation, runtime check, closing
PASS credential gate: all operations, SYSDBA, required password, inactive-click reminders, service guard, cleanup
PASS credential privacy: stdin-only transfer, stdout/stderr redaction, full log, history, export, notifications, exceptions, zeroed buffers
PASS branding: embedded logo, 7 icon sizes, different working directory, light/dark renders at 1240x820 and 1080x720
PASS embedded Firebird 4.0.7: create, analysis, backup, restore, validation, restored row
ALL 9 REGRESSION TESTS PASSED
```

Os testes de interface executaram o dispatcher e os controles WPF sem abrir janelas visíveis. Verificaram trabalho síncrono fora da thread da interface, navegação durante uma operação, bloqueio de operações concorrentes, cancelamento com callback demorado, limites da prévia dos logs, persistência de todas as 60 mil linhas e pesquisa de uma linha antiga.

O teste de avisos verificou uma única notificação para sucesso, pendências, falha, resultado inconclusivo e interrupção; conteúdo e ícones corretos; execução na thread WPF após liberar os controles; resultado salvo no histórico; falhas inesperadas; cancelamento; verificação explícita do runtime; ausência de aviso na descoberta inicial e durante o fechamento. O teste intercepta a chamada de apresentação; a aplicação distribuída usa `MessageBox.Show` com a janela principal como proprietária e botão OK.

O teste de integração criou um FDB com tabela e registro, analisou sua integridade, criou um FBK, restaurou um novo FDB, testou a abertura, validou o FDB restaurado e conferiu o conteúdo do registro. Os caminhos de integração continham espaços.

Os testes de credenciais confirmaram bloqueio de todos os comandos inicialmente; rejeição de usuário diferente de SYSDBA, senha ausente ou só com espaços; normalização do nome; lembrete ao clicar na área do comando inativo ou na navegação; proteção nos handlers, dispatcher e quatro serviços. A conclusão, falha e interrupção limpam o campo e zeram os buffers de senha próprios do aplicativo.

Uma fixture descartável reproduziu uma senha sintética em stdout e stderr para conferir o envio por stdin e a ocultação antes da captura. Testes separados reproduziram a senha em progresso, firebird.log acompanhado, resultado e exceção; conferiram a ausência no log completo, interface, histórico, arquivos exportados, preferências e notificações. Os seis construtores de comandos não incluem a senha nos argumentos. Máscaras com senhas curtas ou iguais ao texto de ocultação foram verificadas quanto à ocultação e idempotência.

O teste embedded usou senha sintética por stdin nas ferramentas reais. Isso verifica o transporte da senha, não a autenticação: Engine13 não valida a senha. Nenhuma senha real do usuário foi utilizada ou gravada nos testes.

A verificação do runtime também foi aprovada. O aplicativo reconhece que `gbak -z` imprime a versão e termina com código 1 pela ausência de nomes de arquivos; essa resposta documentada pelo próprio utilitário não é mais confundida com falha de inicialização. A versão exibida contém as versões das ferramentas, sem as mensagens de uso.

Para repetir os testes, execute `scripts/test.ps1` com o SDK .NET 8 x64.

## Verificação visual da identidade

PNG e ICO carregaram por recursos incorporados mesmo com o diretório atual apontando para outra pasta. O decoder confirmou os sete tamanhos do ICO. As renderizações WPF nos temas claro e escuro, em 1240 x 820 e 1080 x 720, passaram por verificações de pixels não vazios na área da logo, cor real do fundo, contraste do nome e largura do texto. As imagens também foram inspecionadas visualmente.

Também foram verificados o texto "Desenvolvido por Luan Paranhos.", ausência do campo Role, visibilidade do estado de credenciais e dos controles de exportação/rolagem na janela mínima. O toolbar do log quebra linha e os checkboxes acompanham o contraste do tema.

A logo original tem transparência real. A atualização dos pincéis do tema foi sincronizada com as cores selecionadas e o estilo de janela existente passou a ser aplicado explicitamente.

## Diagnóstico do erro anterior de DLL

O erro “Realocação Inválida da DLL do Sistema” relatado na primeira entrega ocorreu durante a execução dos utilitários dentro do sandbox deste ambiente. A execução fora desse isolamento funcionou: `gfix -z` informou `WI-V4.0.7.3271 Firebird 4.0`, e o fluxo de integração acima terminou com sucesso. Não foi preciso substituir o runtime nem instalar um serviço Firebird.

## Cenários ainda não validados

- Recuperação de fixture com corrupção conhecida e avaliação de perdas lógicas.
- Interrupção de backup/restauração de grande porte com os utilitários reais; o teste de cancelamento cobre o dispatcher e callbacks demorados.
- Execução do pacote em uma segunda máquina Windows 10/11 sem dependências previamente instaladas.
- Caminhos com acentos e bancos multifile ou com dependências externas.

Os testes com banco saudável não comprovam recuperação de corrupção nem ausência de perda de dados nesse cenário.
